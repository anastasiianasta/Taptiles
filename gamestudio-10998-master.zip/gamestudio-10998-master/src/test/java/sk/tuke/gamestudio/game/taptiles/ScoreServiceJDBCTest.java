package sk.tuke.gamestudio.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import sk.tuke.gamestudio.entity.Score;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ScoreServiceJDBCTest {

    private ScoreService scoreService;

    @BeforeEach
    public void setUp() {
        scoreService = new ScoreServiceJDBC();
        scoreService.reset();
    }

    @Test
    public void addScoreAndGetTopScores() {
        scoreService.addScore(new Score("taptiles", "Anastasiia", 150, new Date()));
        scoreService.addScore(new Score("taptiles", "Ira", 250, new Date()));

        List<Score> scores = scoreService.getTopScores("taptiles");

        assertEquals(2, scores.size());
        assertEquals("Ira", scores.get(0).getPlayer());
        assertEquals(250, scores.get(0).getPoints());
        assertEquals("Anastasiia", scores.get(1).getPlayer());
        assertEquals(150, scores.get(1).getPoints());
    }

    @Test
    public void getTopScoresForUnknownGameReturnsEmptyList() {
        List<Score> scores = scoreService.getTopScores("unknown_game");

        assertNotNull(scores);
        assertTrue(scores.isEmpty());
    }

    @Test
    public void resetRemovesAllScores() {
        scoreService.addScore(new Score("taptiles", "Anastasiia", 100, new Date()));
        scoreService.addScore(new Score("taptiles", "Ira", 200, new Date()));

        scoreService.reset();

        List<Score> scores = scoreService.getTopScores("taptiles");
        assertTrue(scores.isEmpty());
    }
}