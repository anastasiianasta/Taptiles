package sk.tuke.gamestudio.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import sk.tuke.gamestudio.entity.Rating;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class RatingServiceJDBCTest {

    private RatingService ratingService;

    @BeforeEach
    public void setUp() {
        ratingService = new RatingServiceJDBC();
        ratingService.reset();
    }

    @Test
    public void setAndGetRating() {
        ratingService.setRating(new Rating("Anastasiia", "taptiles", 4, new Date()));

        int rating = ratingService.getRating("taptiles", "Anastasiia");

        assertEquals(4, rating);
    }

    @Test
    public void setRatingReplacesOldRatingFromSamePlayer() {
        ratingService.setRating(new Rating("Anastasiia", "taptiles", 2, new Date()));
        ratingService.setRating(new Rating("Anastasiia", "taptiles", 5, new Date()));

        int rating = ratingService.getRating("taptiles", "Anastasiia");

        assertEquals(5, rating);
    }

    @Test
    public void getAverageRatingReturnsCorrectAverage() {
        ratingService.setRating(new Rating("Anastasiia", "taptiles", 4, new Date()));
        ratingService.setRating(new Rating("Nika", "taptiles", 5, new Date()));
        ratingService.setRating(new Rating("Olya", "taptiles", 3, new Date()));

        double average = ratingService.getAverageRating("taptiles");

        assertEquals(4.0, average, 0.01);
    }

    @Test
    public void getRatingForUnknownPlayerReturnsZero() {
        int rating = ratingService.getRating("taptiles", "Unknown");

        assertEquals(0, rating);
    }

    @Test
    public void resetRemovesAllRatings() {
        ratingService.setRating(new Rating("Anastasiia", "taptiles", 4, new Date()));

        ratingService.reset();

        assertEquals(0, ratingService.getRating("taptiles", "Anastasiia"));
        assertEquals(0.0, ratingService.getAverageRating("taptiles"), 0.01);
    }
}