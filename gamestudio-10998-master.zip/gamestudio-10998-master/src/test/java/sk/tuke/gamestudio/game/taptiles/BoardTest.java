package sk.tuke.gamestudio.game.taptiles;

import org.junit.jupiter.api.Test;
import sk.tuke.gamestudio.game.taptiles.core.Board;
import sk.tuke.gamestudio.game.taptiles.core.Position;
import sk.tuke.gamestudio.game.taptiles.core.Tile;

import static org.junit.jupiter.api.Assertions.*;

public class BoardTest {

    @Test
    public void generateLevel1CreatesBoard4x4() {
        Board board = new Board();
        board.generate(1);

        assertEquals(4, board.getRows());
        assertEquals(4, board.getCols());
        assertNotNull(board.getTiles());
    }

    @Test
    public void generatedBoardIsNotEmpty() {
        Board board = new Board();
        board.generate(1);

        assertFalse(board.isEmpty());
    }

    @Test
    public void allTilesAreFilledAfterGeneration() {
        Board board = new Board();
        board.generate(1);

        for (int row = 0; row < board.getRows(); row++) {
            for (int col = 0; col < board.getCols(); col++) {
                assertNotNull(board.getTile(row, col));
            }
        }
    }

    @Test
    public void removePairRemovesEqualTiles() {
        Board board = new Board();
        board.setRows(1);
        board.setCols(2);

        Tile[][] tiles = new Tile[1][2];
        tiles[0][0] = new Tile('7');
        tiles[0][1] = new Tile('7');
        board.setTiles(tiles);

        board.removePair(new Position(0, 0), new Position(0, 1));

        assertNull(board.getTile(0, 0));
        assertNull(board.getTile(0, 1));
    }

    @Test
    public void removePairDoesNotRemoveDifferentTiles() {
        Board board = new Board();
        board.setRows(1);
        board.setCols(2);

        Tile[][] tiles = new Tile[1][2];
        tiles[0][0] = new Tile('7');
        tiles[0][1] = new Tile('8');
        board.setTiles(tiles);

        board.removePair(new Position(0, 0), new Position(0, 1));

        assertNotNull(board.getTile(0, 0));
        assertNotNull(board.getTile(0, 1));
        assertEquals('7', board.getTile(0, 0).getSymbol());
        assertEquals('8', board.getTile(0, 1).getSymbol());
    }
}