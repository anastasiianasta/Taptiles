package sk.tuke.gamestudio.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import sk.tuke.gamestudio.entity.Comment;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CommentServiceJDBCTest {

    private CommentService commentService;

    @BeforeEach
    public void setUp() {
        commentService = new CommentServiceJDBC();
        commentService.reset();
    }

    @Test
    public void addCommentAndGetComments() {
        commentService.addComment(new Comment("Anastasiia", "taptiles", "Very good game", new Date()));

        List<Comment> comments = commentService.getComments("taptiles");

        assertEquals(1, comments.size());
        assertEquals("Anastasiia", comments.get(0).getPlayer());
        assertEquals("taptiles", comments.get(0).getGame());
        assertEquals("Very good game", comments.get(0).getComment());
    }

    @Test
    public void getCommentsForUnknownGameReturnsEmptyList() {
        List<Comment> comments = commentService.getComments("unknown_game");

        assertNotNull(comments);
        assertTrue(comments.isEmpty());
    }

    @Test
    public void resetRemovesAllComments() {
        commentService.addComment(new Comment("Anastasiia", "taptiles", "Nice", new Date()));
        commentService.addComment(new Comment("Nika", "taptiles", "Cool", new Date()));

        commentService.reset();

        List<Comment> comments = commentService.getComments("taptiles");
        assertTrue(comments.isEmpty());
    }
}