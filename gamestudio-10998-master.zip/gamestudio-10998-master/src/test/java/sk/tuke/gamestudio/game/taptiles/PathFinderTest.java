package sk.tuke.gamestudio.game.taptiles;

import org.junit.jupiter.api.Test;
import sk.tuke.gamestudio.game.taptiles.core.Board;
import sk.tuke.gamestudio.game.taptiles.core.Position;
import sk.tuke.gamestudio.game.taptiles.core.Tile;
import sk.tuke.gamestudio.game.taptiles.logic.PathFinder;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class PathFinderTest {

    @Test
    public void canConnectThroughOutsideBorder() {
        Board board = new Board();
        board.setRows(4);
        board.setCols(4);

        Tile[][] tiles = new Tile[4][4];

        tiles[0][0] = null;
        tiles[0][1] = null;
        tiles[0][2] = null;
        tiles[0][3] = null;

        tiles[1][0] = null;
        tiles[1][1] = null;
        tiles[1][2] = null;
        tiles[1][3] = null;

        tiles[2][0] = null;
        tiles[2][1] = null;
        tiles[2][2] = null;
        tiles[2][3] = new Tile('2');

        tiles[3][0] = null;
        tiles[3][1] = new Tile('7');
        tiles[3][2] = new Tile('2');
        tiles[3][3] = new Tile('7');

        board.setTiles(tiles);

        PathFinder pathFinder = new PathFinder();

        assertTrue(pathFinder.canConnect(board, new Position(3, 1), new Position(3, 3)));
    }
}