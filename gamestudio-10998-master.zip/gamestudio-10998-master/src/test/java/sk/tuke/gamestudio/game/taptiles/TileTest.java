package sk.tuke.gamestudio.game.taptiles;

import org.junit.jupiter.api.Test;
import sk.tuke.gamestudio.game.taptiles.core.Tile;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TileTest {

    @Test
    public void testTileSymbol() {
        Tile tile = new Tile('A');

        assertEquals('A', tile.getSymbol());
    }
}