package sk.tuke.gamestudio.game.taptiles;

import org.junit.jupiter.api.Test;
import sk.tuke.gamestudio.game.taptiles.core.Position;

import static org.junit.jupiter.api.Assertions.*;

public class PositionTest {
    @Test
    public void testPosition() {
        Position p = new Position(2, 3);

        assertEquals(2, p.getRow());
        assertEquals(3, p.getCol());
    }
}
