package sk.tuke.gamestudio.server.security;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import sk.tuke.gamestudio.entity.TaptilesUser;
import sk.tuke.gamestudio.repository.UserRepository;

@Service
public class TaptilesUserDetailsService implements UserDetailsService {
    private final UserRepository userRepository;

    public TaptilesUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        TaptilesUser taptilesUser = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        return User.withUsername(taptilesUser.getUsername()).password(taptilesUser.getPassword())
                .authorities(taptilesUser.getRole().name())
                .build();
    }
}
